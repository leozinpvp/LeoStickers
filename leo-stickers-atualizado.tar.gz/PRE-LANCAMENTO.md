# Léo Stickers — atualização de pré-lançamento

Este pacote prepara a base do bot para testes internos e um beta fechado. **Não é uma autorização para começar a cobrar clientes ainda**: as integrações externas precisam ser configuradas e testadas no ambiente real do projeto.

## O que foi alterado

### 1. Figurinhas e biblioteca inteligente

- `!s`: cria figurinha preenchendo o quadro 512×512; pode deformar a proporção.
- `!fig`: preserva a proporção, completando o espaço restante com transparência.
- Os dois comandos aceitam foto e vídeo. Vídeos viram WebP animado, respeitando o limite configurado (máximo de 10 segundos) e tentando reduzir o arquivo para até 500 KB.
- `!sn`: modo deformado sem metadados.
- `!figanimada`: mantido como compatibilidade com o comando antigo; continua convertendo vídeo no modo que preserva proporção.
- `!buscarfig tema [quantidade]`: pesquisa **somente as figurinhas já existentes na biblioteca**; quantidade padrão 5, máximo 10.
- `!statusbiblioteca`: mostra total, itens classificados e pendentes.
- `!reindexarfigs`: dono analisa o próximo lote (24 itens por padrão).
- `!reindexarfigs 100`: analisa até 100 itens pendentes.
- `!reindexarfigs tudo`: tenta analisar até 2.000 itens pendentes. Para uma biblioteca grande, é melhor avançar em lotes e observar limites/custos da API.

O Gemini classifica cada figurinha durante a indexação; a busca normal consulta o índice local `figurinhas/ia-index.json`, não envia toda a biblioteca ao Gemini a cada pesquisa. Novas figurinhas coletadas precisam ser indexadas para aparecer na busca inteligente. O índice é um arquivo local e deve entrar nos backups do servidor.

Configure `GEMINI_API_KEY` no `.env`. Não coloque a chave diretamente no código, no Git ou em mensagens. Uma chave que tenha sido compartilhada deve ser revogada e substituída.

### 2. Solicitações de entrada e avisos no PV

- O comando `!aprovarsolicitacao CÓDIGO` agora é encaminhado ao módulo de aprovação correto.
- Os registros guardam separadamente o identificador usado no grupo (LID, quando existir) e o número de telefone usado no PV.
- Na aprovação/recusa, o bot tenta recuperar o número pelo mapeamento LID do Baileys. Se não encontrar, tenta o LID como último recurso.
- Falhas de envio no privado aparecem na resposta do grupo e nos logs, em vez de serem silenciosamente ignoradas.
- A reconciliação de membros considera os aliases PN/LID dos registros antigos.

O WhatsApp pode impedir mensagens privadas para alguém que nunca iniciou conversa com o bot ou que restringiu mensagens. Nesses casos, o bot informa a falha; a pessoa deve abrir o PV e enviar uma mensagem ao bot para iniciar a conversa. Isso não pode ser garantido apenas pelo código.

### 3. Aluguel e Pix

Comandos planejados/implementados na base:

- `!planos`
- `!alugar basic`, `!alugar pro` ou `!alugar premium`
- `!renovar` — cria uma nova cobrança Pix; não renova sem pagamento.
- `!meualuguel`
- `!pagamento`
- `!clientes` e `!aluguéis` — proprietário
- `!revogar ID_DO_GRUPO` — proprietário

O sistema cria links de pagamento Pix do Asaas, associa cada cobrança ao grupo e ao plano, e só ativa a licença depois de consultar o pagamento na API e validar status recebido, tipo Pix, valor e referência/link. Eventos repetidos são tratados de forma idempotente. O sistema mantém no máximo uma cobrança pendente por grupo; não cria outro link enquanto existir uma cobrança em aberto, para evitar pagamentos duplicados.

**A renovação é por novo pagamento Pix mensal solicitado pelo administrador.** Este código não faz débito automático nem cria uma recorrência que cobre sozinha todo mês.

#### Configuração do Asaas

1. Crie/obtenha credenciais de sandbox e configure `ASAAS_API_KEY`.
2. Deixe `ASAAS_API_BASE=https://api-sandbox.asaas.com/v3` durante os testes.
3. Gere um segredo longo e aleatório para `ASAAS_WEBHOOK_TOKEN` (separado da API Key).
4. Publique a rota `/webhooks/asaas` em um endpoint HTTPS público e configure no painel do Asaas o mesmo token no mecanismo de autenticação do webhook.
5. Encaminhe a rota pública para a porta definida em `ASAAS_WEBHOOK_PORT` (padrão 3333).
6. Faça testes completos com cobranças de sandbox: pagamento aprovado, valor incorreto, evento duplicado, link expirado, renovação e falha de webhook.
7. Só depois da validação, configure credenciais e URL de produção e teste novamente com uma cobrança controlada.

Um processo rodando somente no Termux/celular, sem endereço público HTTPS ou proxy/túnel configurado, não recebe webhooks externos do Asaas. Para venda comercial, prefira hospedar o bot e o webhook em servidor com disponibilidade, TLS, backups e monitoramento.

`RENTAL_ENFORCEMENT_ENABLED=false` por padrão. Mantenha assim no beta até confirmar que cobrança, webhook, licença, renovação e restauração de backup funcionam. Ao ativar `true`, grupos sem licença ativa ficam bloqueados para comandos (com exceções para consultar planos, pagar e administrar a licença).

Os preços Basic/Pro/Premium em `.env.example` são **valores hipotéticos**. A autorização comercial e a separação de funcionalidades por plano ainda precisam ser definidas/validadas; neste pacote, a licença identifica o plano e controla o acesso do grupo, mas não implementa uma matriz completa de recursos exclusivos por plano.

### 4. Segurança e dados

- `.env` real, sessão do WhatsApp, banco de aluguel, índice da IA e dados dinâmicos não devem ser enviados ao Git nem distribuídos no pacote.
- `rental-data.json` e `figurinhas/ia-index.json` são dados persistentes locais; inclua-os em backups privados regulares.
- O webhook verifica o token de autenticação do Asaas e registra o evento antes de responder HTTP 200.
- Não libere aluguel com base em print/comprovante enviado no grupo.
- Antes da venda: publicar termos de uso, política de privacidade, política de cancelamento, canal de suporte e procedimento de exclusão de dados.
- A automação via WhatsApp/Baileys é não oficial e pode estar sujeita a bloqueios ou mudanças da plataforma. Não prometa disponibilidade absoluta.

## O que ainda não está pronto para produção

- Configurar e validar a chave Gemini no `.env` e indexar o acervo existente.
- Configurar Asaas sandbox, endpoint HTTPS público, webhook e concluir testes ponta a ponta.
- Confirmar os recursos e os preços de cada plano; a matriz de funções por plano ainda não está aplicada.
- Instalar/validar o módulo econômico V3. O usuário informou que ainda não o instalou; este pacote não o declara como pronto.
- Testar conexão, comandos, aprovação/privado, animações, coleta, backup/restauração e licenças no WhatsApp real.
- Fazer beta fechado com 3–5 grupos antes de vender.
- Preparar hospedagem permanente, monitoramento, termos, privacidade, suporte e processo de cancelamento.

## Verificação feita neste pacote

- `npm test`: passou.
- Sintaxe: válida em 18 arquivos JavaScript.
- Testes unitários: 10/10 aprovados.

Esses testes são estáticos/unitários. Não substituem teste no WhatsApp, chamada real ao Gemini, chamada ao Asaas ou webhook público. O pacote recebido não contém o `.env`, a sessão do WhatsApp, `config.json`, o catálogo/arquivos da biblioteca de figurinhas ou a base de dados real; a atualização deve ser aplicada sobre a pasta atual preservando esses dados.
