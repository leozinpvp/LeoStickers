import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';

const STATE_FILE = path.resolve(process.env.LEO_RENTAL_DATA_FILE || './rental-data.json');
const ASAAS_BASE = String(process.env.ASAAS_API_BASE || 'https://api-sandbox.asaas.com/v3').replace(/\/$/, '');
const WEBHOOK_PATH = process.env.ASAAS_WEBHOOK_PATH || '/webhooks/asaas';
const WEBHOOK_PORT = Math.max(1, Math.min(65535, Number(process.env.ASAAS_WEBHOOK_PORT || 3333)));
const ENFORCEMENT = /^(true|1|on|yes)$/i.test(String(process.env.RENTAL_ENFORCEMENT_ENABLED || 'false').trim());
const DAY_MS = 24 * 60 * 60 * 1000;

const PLANS = Object.freeze({
  basic: {
    name: 'Basic',
    value: readPrice('LS_PRICE_BASIC', 14.90),
    description: 'Recursos básicos de figurinhas e biblioteca compartilhada.'
  },
  pro: {
    name: 'Pro',
    value: readPrice('LS_PRICE_PRO', 24.90),
    description: 'Recursos de figurinhas, animação, biblioteca inteligente, jogos e economia conforme disponibilidade.'
  },
  premium: {
    name: 'Premium',
    value: readPrice('LS_PRICE_PREMIUM', 39.90),
    description: 'Recursos Pro e opções avançadas de personalização e suporte.'
  }
});

let currentSock = null;
let webhookServer = null;
let processingEvents = false;
let expiryTimer = null;

function readPrice(envName, fallback) {
  const value = Number(String(process.env[envName] || '').replace(',', '.'));
  return Number.isFinite(value) && value > 0 ? Math.round(value * 100) / 100 : fallback;
}

function emptyState() {
  return { version: 1, links: {}, licenses: {}, events: {}, payments: {}, updatedAt: null };
}

function loadState() {
  try {
    const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (!state || typeof state !== 'object') return emptyState();
    state.links ||= {};
    state.licenses ||= {};
    state.events ||= {};
    state.payments ||= {};
    return state;
  } catch (error) {
    if (error.code !== 'ENOENT') console.error('[ALUGUEL] Não consegui ler o banco de aluguéis:', error.message);
    return emptyState();
  }
}

function saveState(state) {
  state.updatedAt = new Date().toISOString();
  fs.mkdirSync(path.dirname(STATE_FILE), { recursive: true });
  const temp = `${STATE_FILE}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(temp, JSON.stringify(state, null, 2), { mode: 0o600 });
  fs.renameSync(temp, STATE_FILE);
  try { fs.chmodSync(STATE_FILE, 0o600); } catch {}
}

function normalizeJid(value) {
  const raw = String(value || '').trim().toLowerCase();
  if (!raw) return '';
  const at = raw.lastIndexOf('@');
  if (at < 0) return raw.split(':')[0].replace(/\D/g, '') + '@s.whatsapp.net';
  return `${raw.slice(0, at).split(':')[0]}${raw.slice(at)}`;
}

function jidAliases(value) {
  const result = new Set();
  const add = item => {
    if (!item) return;
    if (typeof item === 'object') {
      for (const key of ['id', 'jid', 'lid', 'phoneNumber', 'pn', 'participant', 'participantAlt']) add(item[key]);
      return;
    }
    const normalized = normalizeJid(item);
    if (normalized) result.add(normalized);
  };
  add(value);
  return result;
}

function aliasesMatch(a, b) {
  for (const value of a) if (b.has(value)) return true;
  return false;
}

function money(value) {
  return Number(value).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
}

function planText() {
  return [
    '🦊 PLANOS LÉO STICKERS — mensal',
    '',
    ...Object.entries(PLANS).map(([key, plan]) => `• *${plan.name}* — ${money(plan.value)}\n  !alugar ${key}\n  ${plan.description}`),
    '',
    'Os valores são configuráveis no .env e ainda precisam ser validados antes da abertura comercial.'
  ].join('\n');
}

function addOneMonth(date) {
  const source = new Date(date);
  const year = source.getUTCFullYear();
  const month = source.getUTCMonth();
  const day = source.getUTCDate();
  const nextMonth = new Date(Date.UTC(year, month + 1, 1, source.getUTCHours(), source.getUTCMinutes(), source.getUTCSeconds()));
  const lastDay = new Date(Date.UTC(nextMonth.getUTCFullYear(), nextMonth.getUTCMonth() + 1, 0)).getUTCDate();
  nextMonth.setUTCDate(Math.min(day, lastDay));
  return nextMonth;
}

export function isRentalEnforcementEnabled() {
  return ENFORCEMENT;
}

export function hasActiveRental(groupJid) {
  if (!String(groupJid || '').endsWith('@g.us')) return false;
  const license = loadState().licenses[groupJid];
  return Boolean(license && license.status === 'active' && Date.parse(license.expiresAt || '') > Date.now());
}

export function isRentalExemptCommand(command) {
  return new Set([
    'planos', 'alugar', 'meualuguel', 'pagamento', 'info', 'menu', 'ajuda', 'help',
    'regrasgrupo', 'regras', 'entrada', 'autoaceitar', 'autoaprovarsolicitacao',
    'solicitacoes', 'aprovarsolicitacao', 'recusarsolicitacao', 'statusbiblioteca',
    'clientes', 'aluguéis', 'alugueis', 'renovar', 'revogar', 'revogarrental'
  ]).has(String(command || '').toLowerCase());
}

function assertAsaasConfigured() {
  if (!process.env.ASAAS_API_KEY?.trim()) throw new Error('ASAAS_API_KEY não configurada no .env.');
  if (!process.env.ASAAS_WEBHOOK_TOKEN?.trim()) throw new Error('ASAAS_WEBHOOK_TOKEN não configurado no .env.');
}

async function asaasRequest(endpoint, { method = 'GET', body } = {}) {
  const apiKey = process.env.ASAAS_API_KEY?.trim();
  if (!apiKey) throw new Error('ASAAS_API_KEY não configurada no .env.');
  const response = await fetch(`${ASAAS_BASE}${endpoint}`, {
    method,
    headers: {
      accept: 'application/json',
      'content-type': 'application/json',
      access_token: apiKey
    },
    body: body ? JSON.stringify(body) : undefined,
    signal: AbortSignal.timeout(30000)
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    const detail = payload?.errors?.map(item => item.description || item.code).filter(Boolean).join('; ');
    throw new Error(detail || payload?.message || `Asaas respondeu HTTP ${response.status}.`);
  }
  return payload;
}

async function isRequesterGroupAdmin(ctx) {
  if (ctx.isOwner?.(ctx.sender)) return true;
  if (!String(ctx.jid || '').endsWith('@g.us')) return false;
  const metadata = await ctx.sock.groupMetadata(ctx.jid);
  const senderAliases = new Set([
    ...jidAliases(ctx.sender),
    ...jidAliases(ctx.msg?.key?.participant),
    ...jidAliases(ctx.msg?.key?.participantAlt)
  ]);
  return (metadata.participants || []).some(participant =>
    aliasesMatch(senderAliases, jidAliases(participant)) &&
    (participant.admin === 'admin' || participant.admin === 'superadmin' || participant.isAdmin === true || participant.isSuperAdmin === true)
  );
}

function latestPendingLink(state, groupJid) {
  return Object.values(state.links)
    .filter(link => link.groupJid === groupJid && link.status === 'pending')
    .sort((a, b) => String(b.createdAt).localeCompare(String(a.createdAt)))[0] || null;
}

async function createCheckout(ctx, planKey) {
  const plan = PLANS[planKey];
  if (!plan) throw new Error('Plano inválido. Escolha basic, pro ou premium.');
  if (!String(ctx.jid || '').endsWith('@g.us')) throw new Error('Use !alugar dentro do grupo que deseja ativar.');
  if (!(await isRequesterGroupAdmin(ctx))) throw new Error('Somente um administrador do grupo pode criar o aluguel.');
  assertAsaasConfigured();

  const state = loadState();
  const existing = latestPendingLink(state, ctx.jid);
  if (existing) {
    if (existing.plan !== planKey) {
      throw new Error(`Já existe uma cobrança pendente do plano ${existing.planName} para este grupo. Consulte !pagamento; não vou criar outro link para evitar cobranças duplicadas.`);
    }
    await ctx.send(ctx.jid, `🧾 Já existe uma cobrança pendente para este grupo.\nPlano: ${existing.planName}\nValor: ${money(existing.value)}\nPague aqui: ${existing.url}\n\nUse !pagamento para consultar.`, ctx.msg);
    return true;
  }

  const externalReference = `LS-${crypto.randomBytes(16).toString('hex').toUpperCase()}`;
  const payload = await asaasRequest('/paymentLinks', {
    method: 'POST',
    body: {
      name: `Léo Stickers ${plan.name} - aluguel mensal`,
      description: `Assinatura mensal do grupo ${ctx.jid}. Referência: ${externalReference}`,
      value: plan.value,
      billingType: 'PIX',
      chargeType: 'DETACHED',
      externalReference,
      notificationEnabled: false,
      limit: 1
    }
  });

  if (!payload?.id || !payload?.url) throw new Error('O Asaas não retornou o ID e a URL da cobrança.');
  state.links[externalReference] = {
    externalReference,
    asaasLinkId: String(payload.id),
    url: String(payload.url),
    groupJid: ctx.jid,
    requesterJid: normalizeJid(ctx.sender),
    plan: planKey,
    planName: plan.name,
    value: plan.value,
    status: 'pending',
    createdAt: new Date().toISOString()
  };
  saveState(state);
  await ctx.send(ctx.jid, `🧾 COBRANÇA PIX GERADA\n\nPlano: *${plan.name}*\nValor: *${money(plan.value)} / mês*\n\nPague pelo link oficial do Asaas:\n${payload.url}\n\nA licença só será ativada depois que o Asaas confirmar o pagamento.`, ctx.msg);
  return true;
}

function licenseSummary(groupJid) {
  const license = loadState().licenses[groupJid];
  if (!license) return '📭 Este grupo ainda não possui aluguel registrado.';
  const active = license.status === 'active' && Date.parse(license.expiresAt || '') > Date.now();
  return [
    `🦊 ALUGUEL — ${license.planName || license.plan}`,
    `Status: ${active ? '🟢 ATIVO' : '🔴 EXPIRADO/INATIVO'}`,
    `Válido até: ${new Date(license.expiresAt).toLocaleString('pt-BR')}`,
    `Último pagamento: ${license.lastPaymentId || 'não registrado'}`
  ].join('\n');
}

function paymentSummary(groupJid) {
  const pending = latestPendingLink(loadState(), groupJid);
  if (!pending) return 'Não encontrei cobrança pendente para este grupo. Use !alugar pro para gerar uma nova cobrança.';
  return `🧾 PAGAMENTO PENDENTE\nPlano: ${pending.planName}\nValor: ${money(pending.value)}\nCriado em: ${new Date(pending.createdAt).toLocaleString('pt-BR')}\nLink: ${pending.url}`;
}

async function listRentals(ctx) {
  if (!ctx.isOwner?.(ctx.sender)) {
    await ctx.send(ctx.jid, '❌ Comando exclusivo do proprietário do bot.', ctx.msg);
    return true;
  }
  const state = loadState();
  const licenses = Object.values(state.licenses);
  const pending = Object.values(state.links).filter(link => link.status === 'pending');
  const active = licenses.filter(item => item.status === 'active' && Date.parse(item.expiresAt || '') > Date.now());
  const text = [
    `🦊 CLIENTES / ALUGUÉIS`,
    `Licenças ativas: ${active.length}`,
    `Cobranças pendentes: ${pending.length}`,
    '',
    ...licenses.slice(-40).reverse().map(item => `• ${item.groupJid} — ${item.planName || item.plan} — ${item.status} — até ${new Date(item.expiresAt).toLocaleDateString('pt-BR')}`)
  ].join('\n');
  await ctx.send(ctx.jid, text.slice(0, 3500), ctx.msg);
  return true;
}

async function manageLicense(ctx, action, value) {
  if (!ctx.isOwner?.(ctx.sender)) {
    await ctx.send(ctx.jid, '❌ Comando exclusivo do proprietário do bot.', ctx.msg);
    return true;
  }
  const target = String(value || '').trim() || (String(ctx.jid).endsWith('@g.us') ? ctx.jid : '');
  if (!target) {
    await ctx.send(ctx.jid, `Use !${action} ID_DO_GRUPO. Você também pode executar o comando dentro do próprio grupo.`, ctx.msg);
    return true;
  }
  const state = loadState();
  const license = state.licenses[target];
  if (action === 'revogar' || action === 'revogarrental') {
    if (!license) {
      await ctx.send(ctx.jid, 'Não encontrei licença para esse grupo.', ctx.msg);
      return true;
    }
    license.status = 'revoked';
    license.revokedAt = new Date().toISOString();
    saveState(state);
    await ctx.send(ctx.jid, `✅ Licença revogada para ${target}.`, ctx.msg);
    return true;
  }
  return false;
}

export async function handleRentalCommand(ctx) {
  const command = String(ctx.command || '').toLowerCase();
  if (command === 'planos') {
    await ctx.send(ctx.jid, planText(), ctx.msg);
    return true;
  }
  if (command === 'alugar') {
    try { return await createCheckout(ctx, String(ctx.value || '').trim().toLowerCase() || 'pro'); }
    catch (error) {
      await ctx.send(ctx.jid, `❌ Não consegui criar o aluguel: ${String(error?.message || error).slice(0, 220)}`, ctx.msg);
      return true;
    }
  }
  if (command === 'meualuguel') {
    if (!String(ctx.jid || '').endsWith('@g.us')) {
      await ctx.send(ctx.jid, 'Use !meualuguel dentro do grupo.', ctx.msg);
    } else {
      await ctx.send(ctx.jid, licenseSummary(ctx.jid), ctx.msg);
    }
    return true;
  }
  if (command === 'pagamento') {
    if (!String(ctx.jid || '').endsWith('@g.us')) {
      await ctx.send(ctx.jid, 'Use !pagamento dentro do grupo.', ctx.msg);
    } else {
      await ctx.send(ctx.jid, paymentSummary(ctx.jid), ctx.msg);
    }
    return true;
  }
  if (command === 'clientes' || command === 'aluguéis' || command === 'alugueis') return listRentals(ctx);
  if (command === 'renovar') {
    const state = loadState();
    const license = state.licenses[ctx.jid];
    const plan = String(ctx.value || license?.plan || 'pro').trim().toLowerCase();
    try { return await createCheckout(ctx, plan); }
    catch (error) {
      await ctx.send(ctx.jid, `❌ Não consegui gerar a cobrança de renovação: ${String(error?.message || error).slice(0, 220)}`, ctx.msg);
      return true;
    }
  }
  if (command === 'revogar' || command === 'revogarrental') return manageLicense(ctx, command, ctx.value);
  return false;
}

export function startRentalScheduler(sock) {
  currentSock = sock || currentSock;
  if (expiryTimer) return true;
  const run = async () => {
    const state = loadState();
    const now = Date.now();
    let changed = false;
    for (const license of Object.values(state.licenses)) {
      if (license.status !== 'active') continue;
      const expiresAt = Date.parse(license.expiresAt || '');
      if (!Number.isFinite(expiresAt)) continue;
      if (expiresAt <= now) {
        license.status = 'expired';
        license.expiredAt ||= new Date(now).toISOString();
        changed = true;
        if (!license.expiredNotifiedAt && currentSock) {
          await currentSock.sendMessage(license.groupJid, {
            text: '⏰ O aluguel do Léo Stickers expirou. Um administrador pode consultar !planos e renovar com !renovar.'
          }).catch(error => console.warn('[ALUGUEL] Falha ao avisar expiração:', error?.message || error));
          license.expiredNotifiedAt = new Date(now).toISOString();
          changed = true;
        }
        continue;
      }
      const timeLeft = expiresAt - now;
      if (timeLeft <= 3 * DAY_MS && timeLeft > 0) {
        const reminderKey = new Date(expiresAt).toISOString();
        if (license.lastReminderForExpiry !== reminderKey && currentSock) {
          await currentSock.sendMessage(license.groupJid, {
            text: `🔔 O aluguel do Léo Stickers vence em breve (${new Date(expiresAt).toLocaleDateString('pt-BR')}). Um administrador pode renovar com !renovar.`
          }).catch(error => console.warn('[ALUGUEL] Falha ao avisar vencimento:', error?.message || error));
          license.lastReminderForExpiry = reminderKey;
          changed = true;
        }
      }
    }
    if (changed) saveState(state);
  };
  run().catch(error => console.error('[ALUGUEL] Erro ao verificar vencimentos:', error?.stack || error));
  expiryTimer = setInterval(() => {
    run().catch(error => console.error('[ALUGUEL] Erro ao verificar vencimentos:', error?.stack || error));
  }, 60 * 60 * 1000);
  expiryTimer.unref?.();
  return true;
}

function safeTokenEquals(actual, expected) {
  const a = Buffer.from(String(actual || ''), 'utf8');
  const b = Buffer.from(String(expected || ''), 'utf8');
  return a.length === b.length && a.length > 0 && crypto.timingSafeEqual(a, b);
}

async function verifyAndApplyPayment(paymentId) {
  const state = loadState();
  const normalizedPaymentId = String(paymentId || '').trim();
  if (!normalizedPaymentId) throw new Error('O evento não informou o ID do pagamento.');

  // O Asaas pode emitir eventos diferentes para a mesma cobrança. A chave do
  // pagamento torna a ativação idempotente, mesmo depois que o link foi pago.
  const alreadyApplied = state.payments[normalizedPaymentId];
  if (alreadyApplied) {
    const link = Object.values(state.links).find(item => item.paymentId === normalizedPaymentId) ||
      state.links[alreadyApplied.externalReference] || null;
    return { duplicate: true, license: state.licenses[alreadyApplied.groupJid], link };
  }

  const candidates = Object.values(state.links).filter(link => link.status === 'pending');
  if (!candidates.length) throw new Error('Não há cobrança pendente para conciliar.');

  const payment = await asaasRequest(`/payments/${encodeURIComponent(normalizedPaymentId)}`);
  if (payment.status !== 'RECEIVED') {
    throw new Error(`O pagamento ainda não está confirmado no Asaas (status: ${payment.status || 'desconhecido'}).`);
  }
  if (String(payment.billingType || '').toUpperCase() !== 'PIX') {
    throw new Error('O pagamento recebido não foi identificado como Pix.');
  }

  let link = null;
  const externalReference = String(payment.externalReference || '');
  if (externalReference && state.links[externalReference]) {
    link = state.links[externalReference];
  }
  if (!link && payment.paymentLink) {
    link = candidates.find(item => item.asaasLinkId === String(payment.paymentLink)) || null;
  }
  if (!link) throw new Error('Não consegui associar essa cobrança a um link interno do Léo Stickers. Nenhuma licença foi ativada.');
  if (link.status !== 'pending') throw new Error('Este link já foi encerrado ou utilizado. Nenhuma licença foi ativada.');
  if (payment.paymentLink && String(payment.paymentLink) !== String(link.asaasLinkId)) {
    throw new Error('O identificador do link de pagamento não corresponde ao registro interno.');
  }
  if (externalReference && externalReference !== link.externalReference) {
    throw new Error('A referência externa da cobrança não corresponde ao link registrado.');
  }
  if (Math.round(Number(payment.value) * 100) !== Math.round(Number(link.value) * 100)) {
    throw new Error('O valor pago não corresponde ao valor esperado do plano.');
  }
  if (!link.groupJid?.endsWith('@g.us')) throw new Error('A cobrança não possui grupo de destino válido.');

  const now = Date.now();
  const current = state.licenses[link.groupJid];
  const base = current?.status === 'active' && Date.parse(current.expiresAt || '') > now
    ? new Date(current.expiresAt)
    : new Date(now);
  const expiresAt = addOneMonth(base);
  const license = {
    groupJid: link.groupJid,
    plan: link.plan,
    planName: link.planName,
    status: 'active',
    startedAt: current?.startedAt || new Date(now).toISOString(),
    expiresAt: expiresAt.toISOString(),
    lastPaymentId: normalizedPaymentId,
    lastPaymentValue: Number(payment.value),
    lastPaymentAt: payment.confirmedDate || payment.clientPaymentDate || new Date(now).toISOString(),
    updatedAt: new Date(now).toISOString()
  };
  state.licenses[link.groupJid] = license;
  state.payments[normalizedPaymentId] = {
    paymentId: normalizedPaymentId,
    groupJid: link.groupJid,
    externalReference: link.externalReference,
    value: Number(payment.value),
    confirmedAt: new Date(now).toISOString()
  };
  link.status = 'paid';
  link.paymentId = normalizedPaymentId;
  link.paidAt = new Date(now).toISOString();
  saveState(state);

  // Impede que um link antigo volte a receber pagamentos depois da ativação.
  try {
    await asaasRequest(`/paymentLinks/${encodeURIComponent(link.asaasLinkId)}`, {
      method: 'PUT',
      body: { active: false }
    });
  } catch (error) {
    console.warn('[ALUGUEL] Não consegui desativar o link após pagamento:', error?.message || error);
  }
  return { duplicate: false, license, link };
}

async function processWebhookEvent(eventId, paymentId) {
  const state = loadState();
  const event = state.events[eventId];
  if (!event || event.status === 'processed') return;
  event.status = 'processing';
  event.attemptedAt = new Date().toISOString();
  saveState(state);

  try {
    const result = await verifyAndApplyPayment(paymentId);
    const current = loadState();
    current.events[eventId] ||= {};
    current.events[eventId].status = 'processed';
    current.events[eventId].processedAt = new Date().toISOString();
    current.events[eventId].paymentId = paymentId;
    saveState(current);
    if (!result.duplicate && currentSock && result.license?.groupJid) {
      await currentSock.sendMessage(result.license.groupJid, {
        text: `🦊✅ PAGAMENTO CONFIRMADO!\nPlano: *${result.license.planName}*\nAcesso liberado até: *${new Date(result.license.expiresAt).toLocaleDateString('pt-BR')}*.\nObrigado por alugar o Léo Stickers!`
      }).catch(error => console.warn('[ALUGUEL] Não consegui avisar o grupo:', error?.message || error));
    }
  } catch (error) {
    const current = loadState();
    current.events[eventId] ||= {};
    current.events[eventId].status = 'needs_review';
    current.events[eventId].error = String(error?.message || error).slice(0, 300);
    current.events[eventId].paymentId = paymentId;
    current.events[eventId].updatedAt = new Date().toISOString();
    saveState(current);
    console.error('[ALUGUEL] Pagamento recebido mas não conciliado automaticamente:', error?.stack || error);
    const owner = String(process.env.LEO_OWNER_PRIVATE_JID || '').trim();
    if (owner && currentSock) {
      await currentSock.sendMessage(owner, {
        text: `⚠️ Evento Pix do Asaas precisa de revisão.\nEvento: ${eventId}\nPagamento: ${paymentId}\nMotivo: ${String(error?.message || error).slice(0, 240)}\nNenhuma licença foi liberada.`
      }).catch(() => {});
    }
  }
}

function parseBody(req, maxBytes = 1024 * 1024) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let total = 0;
    req.on('data', chunk => {
      total += chunk.length;
      if (total > maxBytes) {
        reject(new Error('Payload do webhook muito grande.'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => {
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8') || '{}')); }
      catch { reject(new Error('JSON do webhook inválido.')); }
    });
    req.on('error', reject);
  });
}

function drainPendingEvents() {
  if (processingEvents) return;
  processingEvents = true;
  setImmediate(async () => {
    try {
      const state = loadState();
      const pending = Object.entries(state.events).filter(([, event]) => ['received', 'processing', 'needs_review'].includes(event.status) && event.paymentId);
      for (const [eventId, event] of pending) {
        await processWebhookEvent(eventId, event.paymentId);
      }
    } finally {
      processingEvents = false;
    }
  });
}

export function startRentalWebhookServer(sock) {
  currentSock = sock || currentSock;
  if (!process.env.ASAAS_API_KEY?.trim() || !process.env.ASAAS_WEBHOOK_TOKEN?.trim()) {
    console.log('[ALUGUEL] Pix automático não iniciado: configure ASAAS_API_KEY e ASAAS_WEBHOOK_TOKEN no .env.');
    return false;
  }
  if (webhookServer) return true;

  webhookServer = http.createServer(async (req, res) => {
    const requestUrl = new URL(req.url || '/', 'http://localhost');
    if (req.method !== 'POST' || requestUrl.pathname !== WEBHOOK_PATH) {
      res.writeHead(404, { 'content-type': 'text/plain; charset=utf-8' });
      res.end('not found');
      return;
    }
    const expectedToken = process.env.ASAAS_WEBHOOK_TOKEN?.trim();
    if (!safeTokenEquals(req.headers['asaas-access-token'], expectedToken)) {
      res.writeHead(401, { 'content-type': 'text/plain; charset=utf-8' });
      res.end('unauthorized');
      return;
    }

    let body;
    try { body = await parseBody(req); }
    catch (error) {
      res.writeHead(400, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: error.message }));
      return;
    }

    const eventId = String(body.id || '').trim();
    const eventName = String(body.event || '').trim();
    const paymentId = String(body.payment?.id || '').trim();
    if (!eventId) {
      res.writeHead(400, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ error: 'event id ausente' }));
      return;
    }

    const state = loadState();
    if (!state.events[eventId]) {
      state.events[eventId] = {
        eventId,
        event: eventName,
        paymentId,
        status: ['PAYMENT_RECEIVED', 'PAYMENT_CONFIRMED'].includes(eventName) && paymentId ? 'received' : 'ignored',
        receivedAt: new Date().toISOString()
      };
      saveState(state);
    }

    // Asaas exige HTTP 200 após persistência; o processamento ocorre depois.
    res.writeHead(200, { 'content-type': 'application/json' });
    res.end(JSON.stringify({ received: true }));
    if (['PAYMENT_RECEIVED', 'PAYMENT_CONFIRMED'].includes(eventName) && paymentId) drainPendingEvents();
  });

  webhookServer.on('error', error => {
    console.error('[ALUGUEL] Erro no servidor de webhook Pix:', error?.stack || error);
  });
  webhookServer.listen(WEBHOOK_PORT, process.env.ASAAS_WEBHOOK_HOST || '0.0.0.0', () => {
    console.log(`[ALUGUEL] Webhook Asaas aguardando em ${WEBHOOK_PATH} (porta ${WEBHOOK_PORT}).`);
  });
  drainPendingEvents();
  return true;
}

export function stopRentalWebhookServer() {
  if (!webhookServer) return;
  webhookServer.close();
  webhookServer = null;
}

export const __test = {
  normalizeJid,
  addOneMonth,
  safeTokenEquals,
  PLANS,
  hasActiveRental
};
